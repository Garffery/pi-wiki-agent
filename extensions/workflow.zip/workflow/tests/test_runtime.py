"""
Tests for run_workflow — sandbox execution and agent orchestration.
"""
import pytest

from extensions.workflow.workflow import WorkflowRunOptions, run_workflow


class FakeAgent:
    """Mock agent that echoes back the prompt."""

    async def run(self, prompt, *, label=None, schema=None, instructions=None, signal=None):
        return f"result:{prompt}"


@pytest.mark.asyncio
class TestRunBasic:
    async def test_runs_minimal_workflow(self):
        result = await run_workflow(
            """meta = {'name': 'demo', 'description': 'Test workflow'}

phase('Scan')
scan = await agent('scan task', {'label': 'scan'})
return scan
""",
            WorkflowRunOptions(agent=FakeAgent()),
        )
        assert result.agent_count == 1
        assert result.phases == ["Scan"]
        assert result.result == "result:scan task"

    async def test_parallel_execution(self):
        result = await run_workflow(
            """meta = {'name': 'parallel_demo', 'description': 'Parallel test'}

phase('Multi')
results = await parallel([
    lambda: agent('task A', {'label': 'a'}),
    lambda: agent('task B', {'label': 'b'}),
    lambda: agent('task C', {'label': 'c'}),
])
return results
""",
            WorkflowRunOptions(agent=FakeAgent()),
        )
        assert result.agent_count == 3
        assert len(result.result) == 3
        assert result.result[0] == "result:task A"
        assert result.result[1] == "result:task B"
        assert result.result[2] == "result:task C"

    async def test_pipeline_execution(self):
        result = await run_workflow(
            """meta = {'name': 'pipeline_demo', 'description': 'Pipeline test'}

phase('Process')
results = await pipeline(
    ['a', 'b', 'c'],
    lambda item, _original, _idx: agent(f'stage1 {item}', {'label': f's1-{item}'}),
    lambda prev, _original, _idx: agent(f'stage2 {prev}', {'label': f's2-{_idx}'}),
)
return results
""",
            WorkflowRunOptions(agent=FakeAgent()),
        )
        assert result.agent_count == 6  # 3 items * 2 stages
        assert len(result.result) == 3

    async def test_phase_tracking(self):
        result = await run_workflow(
            """meta = {'name': 'phase_demo', 'description': 'Phase tracking'}

phase('First')
await agent('first task', {'label': 'f1'})

phase('Second')
await agent('second task', {'label': 's1'})
await agent('third task', {'label': 's2'})
return True
""",
            WorkflowRunOptions(agent=FakeAgent()),
        )
        assert result.phases == ["First", "Second"]
        assert result.agent_count == 3

    async def test_conditional_phase(self):
        result = await run_workflow(
            """meta = {'name': 'cond_demo', 'description': 'Conditional phase'}

if args and args.get('needs_review'):
    phase('Review')
    await agent('review task', {'label': 'review'})

phase('Build')
await agent('build task', {'label': 'build'})
return True
""",
            WorkflowRunOptions(agent=FakeAgent(), args={"needs_review": False}),
        )
        assert "Review" not in result.phases
        assert "Build" in result.phases

    async def test_loop_phases(self):
        result = await run_workflow(
            """meta = {'name': 'loop_demo', 'description': 'Loop phases'}

for area in ['API', 'UI', 'DB']:
    phase(f'Inspect {area}')
    await agent(f'inspect {area}', {'label': f'inspect-{area}'})
return True
""",
            WorkflowRunOptions(agent=FakeAgent()),
        )
        assert result.phases == ["Inspect API", "Inspect UI", "Inspect DB"]
        assert result.agent_count == 3

    async def test_logging(self):
        result = await run_workflow(
            """meta = {'name': 'log_demo', 'description': 'Logging test'}

log('starting workflow')
await agent('task', {'label': 't1'})
log('workflow complete')
return True
""",
            WorkflowRunOptions(agent=FakeAgent()),
        )
        assert "starting workflow" in result.logs
        assert "workflow complete" in result.logs

    async def test_args_passed_to_script(self):
        result = await run_workflow(
            """meta = {'name': 'args_demo', 'description': 'Args test'}

return {'received': args}
""",
            WorkflowRunOptions(agent=FakeAgent(), args={"key": "value"}),
        )
        assert result.result == {"received": {"key": "value"}}

    async def test_result_is_serializable(self):
        result = await run_workflow(
            """meta = {'name': 'serial_demo', 'description': 'Serial test'}
return {'ok': True, 'count': 42, 'items': ['a', 'b']}
""",
            WorkflowRunOptions(agent=FakeAgent()),
        )
        assert result.result == {"ok": True, "count": 42, "items": ["a", "b"]}  # noqa: E501


@pytest.mark.asyncio
class TestRunErrors:
    async def test_rejects_non_string_phase(self):
        with pytest.raises(TypeError, match="phase title must be a string"):
            await run_workflow(
                """meta = {'name': 'bad', 'description': 'bad'}
phase(123)
return True
""",
                WorkflowRunOptions(agent=FakeAgent()),
            )

    async def test_rejects_non_string_agent_prompt(self):
        with pytest.raises(TypeError, match="agent prompt must be a string"):
            await run_workflow(
                """meta = {'name': 'bad', 'description': 'bad'}
await agent(123, {'label': 'test'})
return True
""",
                WorkflowRunOptions(agent=FakeAgent()),
            )

    async def test_rejects_unserializable_result(self):
        with pytest.raises(ValueError, match="JSON-serializable"):
            await run_workflow(
                """meta = {'name': 'bad', 'description': 'bad'}
return {1, 2, 3}
""",
                WorkflowRunOptions(agent=FakeAgent()),
            )
