"""
Tests for parse_workflow_script — meta extraction and validation.
"""
import pytest

from extensions.workflow.workflow import parse_workflow_script


VALID_SCRIPT = """meta = {
  'name': 'demo_workflow',
  'description': 'A useful workflow',
  'when_to_use': 'When testing parser behavior',
  'phases': [{'title': 'Scan', 'detail': 'Collect inputs', 'model': 'default'}]
}

phase('Scan')
result = {'ok': True}
"""


class TestParseValid:
    def test_extracts_meta_fields(self):
        meta, body = parse_workflow_script(VALID_SCRIPT)
        assert meta.name == "demo_workflow"
        assert meta.description == "A useful workflow"
        assert meta.when_to_use == "When testing parser behavior"
        assert meta.phases is not None
        assert len(meta.phases) == 1
        assert meta.phases[0].title == "Scan"
        assert meta.phases[0].detail == "Collect inputs"
        assert meta.phases[0].model == "default"

    def test_body_excludes_meta_statement(self):
        meta, body = parse_workflow_script(VALID_SCRIPT)
        assert "meta =" not in body
        assert "phase('Scan')" in body
        assert "result = {'ok': True}" in body

    def test_accepts_minimal_meta(self):
        script = "meta = {'name': 'm', 'description': 'd'}\nresult = 1"
        meta, body = parse_workflow_script(script)
        assert meta.name == "m"
        assert meta.description == "d"
        assert meta.phases is None
        assert meta.when_to_use is None

    def test_accepts_phases_as_list(self):
        script = """meta = {
  'name': 'm',
  'description': 'd',
  'phases': [{'title': 'One'}, {'title': 'Two', 'detail': 'second'}]
}
result = 1"""
        meta, body = parse_workflow_script(script)
        assert meta.phases is not None
        assert len(meta.phases) == 2
        assert meta.phases[0].title == "One"
        assert meta.phases[0].detail is None
        assert meta.phases[1].title == "Two"
        assert meta.phases[1].detail == "second"

    def test_accepts_when_to_use_camelcase(self):
        script = "meta = {'name': 'm', 'description': 'd', 'whenToUse': 'test'}\nresult = 1"
        meta, body = parse_workflow_script(script)
        assert meta.when_to_use == "test"


class TestParseRejects:
    def test_rejects_empty_script(self):
        with pytest.raises(ValueError, match="empty"):
            parse_workflow_script("")

    def test_rejects_meta_not_first(self):
        script = "x = 1\nmeta = {'name': 'demo', 'description': 'desc'}"
        with pytest.raises(ValueError, match="first assignment must be to `meta`"):
            parse_workflow_script(script)

    def test_rejects_missing_name(self):
        script = "meta = {'description': 'desc'}\nresult = 1"
        with pytest.raises(ValueError, match="meta.name"):
            parse_workflow_script(script)

    def test_rejects_missing_description(self):
        script = "meta = {'name': 'demo'}\nresult = 1"
        with pytest.raises(ValueError, match="meta.description"):
            parse_workflow_script(script)

    def test_rejects_empty_name(self):
        script = "meta = {'name': '  ', 'description': 'desc'}\nresult = 1"
        with pytest.raises(ValueError, match="meta.name"):
            parse_workflow_script(script)

    def test_rejects_none_name(self):
        script = "meta = {'name': None, 'description': 'desc'}\nresult = 1"
        with pytest.raises(ValueError, match="meta.name"):
            parse_workflow_script(script)

    def test_rejects_non_dict_meta(self):
        script = "meta = [1, 2, 3]\nresult = 1"
        with pytest.raises(ValueError, match="must be a dict"):
            parse_workflow_script(script)

    def test_rejects_function_call_in_meta(self):
        script = "meta = {'name': str('demo'), 'description': 'desc'}\nresult = 1"
        with pytest.raises(ValueError, match="non-literal"):
            parse_workflow_script(script)

    def test_rejects_variable_in_meta(self):
        script = "meta = {'name': some_var, 'description': 'desc'}\nresult = 1"
        with pytest.raises(ValueError, match="non-literal"):
            parse_workflow_script(script)

    def test_rejects_dict_unpacking_in_meta(self):
        script = "meta = {**base, 'name': 'demo', 'description': 'desc'}\nresult = 1"
        with pytest.raises(ValueError, match="dict unpacking"):
            parse_workflow_script(script)

    def test_rejects_phases_not_list(self):
        script = "meta = {'name': 'm', 'description': 'd', 'phases': 'not a list'}\nresult = 1"
        with pytest.raises(ValueError, match="meta.phases"):
            parse_workflow_script(script)

    def test_rejects_phase_without_title(self):
        script = "meta = {'name': 'm', 'description': 'd', 'phases': [{'detail': 'no title'}]}\nresult = 1"
        with pytest.raises(ValueError, match="title"):
            parse_workflow_script(script)

    def test_rejects_import_statement(self):
        script = "meta = {'name': 'm', 'description': 'd'}\nimport os"
        with pytest.raises(ValueError, match="import"):
            parse_workflow_script(script)

    def test_rejects_open_call_in_body(self):
        script = "meta = {'name': 'm', 'description': 'd'}\nopen('/etc/passwd')"
        with pytest.raises(ValueError, match="open"):
            parse_workflow_script(script)

    def test_rejects_eval_call_in_body(self):
        script = "meta = {'name': 'm', 'description': 'd'}\neval('1+1')"
        with pytest.raises(ValueError, match="eval"):
            parse_workflow_script(script)
