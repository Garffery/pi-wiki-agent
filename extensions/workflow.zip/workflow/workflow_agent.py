"""
In-memory subagent runner for workflow orchestration.

Mirrors src/agent.ts from pi-dynamic-workflows.
Each agent() call spawns a fresh AgentSession that runs in a temp session directory.
"""
from __future__ import annotations

import asyncio
from typing import Any

from pi_ai.types import AssistantMessage, TextContent
from pi_coding_agent.core.agent_session import AgentSession
from pi_coding_agent.core.auth_storage import AuthStorage
from pi_coding_agent.core.model_registry import ModelRegistry
from pi_coding_agent.core.session_manager import SessionManager
from pi_coding_agent.core.settings_manager import Settings
from pi_coding_agent.core.tools import (
    create_bash_tool,
    create_edit_tool,
    create_find_tool,
    create_grep_tool,
    create_ls_tool,
    create_read_tool,
    create_write_tool,
)

from .structured_output import StructuredOutputCapture, create_structured_output_tool


class WorkflowAgent:
    """Creates and runs in-memory subagent sessions."""

    def __init__(
        self,
        *,
        cwd: str,
        model: Any = None,
        model_registry: ModelRegistry | None = None,
        auth_storage: AuthStorage | None = None,
        extra_tools: list | None = None,
    ):
        self.cwd = cwd
        self.model = model
        self.model_registry = model_registry or ModelRegistry()
        self.auth_storage = auth_storage or AuthStorage()
        self.extra_tools = extra_tools or []

    async def run(
        self,
        prompt: str,
        *,
        label: str | None = None,
        schema: dict | None = None,
        instructions: str | None = None,
        signal: asyncio.Event | None = None,
    ) -> Any:
        """
        Run a subagent with the given prompt.

        Args:
            prompt: The task for the subagent.
            label: Short label for logging.
            schema: Optional JSON Schema for structured output.
            instructions: Extra system guidance.
            signal: Abort signal.

        Returns:
            Subagent's final text output, or validated object if schema is provided.
        """
        # ── Build full prompt ──
        parts = [
            instructions,
            f"Task: {prompt}",
        ]
        if label:
            parts.insert(0, f"Task label: {label}")

        enrich_parts: list[str] = []
        if schema:
            enrich_parts.extend([
                "Final output contract:",
                "- Your final action MUST be a structured_output tool call.",
                "- The structured_output arguments are the return value of this subagent.",
                "- Do not emit a prose final answer instead of structured_output.",
                "- If you need to inspect files or run commands first, do so, then call structured_output exactly once.",
            ])

        full_prompt = "\n\n".join([p for p in parts if p] + enrich_parts)

        # ── Build tools ──
        subagent_tools = [
            create_read_tool(self.cwd),
            create_write_tool(self.cwd),
            create_edit_tool(self.cwd),
            create_bash_tool(self.cwd),
            create_grep_tool(self.cwd),
            create_find_tool(self.cwd),
            create_ls_tool(self.cwd),
        ]
        subagent_tools.extend(self.extra_tools)

        # ── Structured output ──
        capture: StructuredOutputCapture | None = None
        if schema:
            capture = StructuredOutputCapture()
            subagent_tools.append(create_structured_output_tool(schema, capture))

        # ── Settings ──
        settings = Settings(
            thinking_level="off",
            model_id=self.model.id if self.model else None,
            provider=self.model.provider if self.model else None,
        )

        # ── Create session ──
        session = AgentSession(
            cwd=self.cwd,
            model=self.model,
            settings=settings,
            session_manager=SessionManager.in_memory(self.cwd),
            auth_storage=self.auth_storage,
            model_registry=self.model_registry,
            extra_tools=subagent_tools,
        )

        # ── Wire abort ──
        abort_handler_installed = False

        async def _on_abort():
            await session.abort()

        try:
            if signal and signal.is_set():
                raise asyncio.CancelledError("Subagent was aborted")

            if signal:
                # Poll signal and abort session when set
                async def _watch_abort():
                    await signal.wait()
                    await session.abort()

                abort_task = asyncio.ensure_future(_watch_abort())
                abort_handler_installed = True

            await session.prompt(full_prompt)

            if signal and signal.is_set():
                raise asyncio.CancelledError("Subagent was aborted")

            # ── Extract result ──
            if schema and capture and capture.called:
                return capture.value

            return self._last_assistant_text(session)

        finally:
            if abort_handler_installed:
                abort_task.cancel()
                try:
                    await abort_task
                except (asyncio.CancelledError, Exception):
                    pass
            session.dispose()

    def _last_assistant_text(self, session: AgentSession) -> str:
        """Extract the last assistant text from session messages."""
        messages = session._agent.state.messages
        for msg in reversed(messages):
            role = getattr(msg, "role", "")
            if role != "assistant":
                continue
            content = getattr(msg, "content", [])
            if not isinstance(content, list):
                continue
            # content is a list of TextContent
            texts = []
            for part in content:
                if hasattr(part, "text"):
                    texts.append(part.text)
                elif isinstance(part, dict) and part.get("type") == "text":
                    texts.append(part["text"])
            text = "".join(texts).strip()
            if text:
                return text
        return ""
