"""
Core workflow engine: script parsing, sandbox execution, agent orchestration.

Mirrors src/workflow.ts from pi-dynamic-workflows.
"""
from __future__ import annotations

import ast
import asyncio
import json as json_module
import math
import os
import time
from dataclasses import dataclass, field
from typing import Any, Callable


# ============================================================================
# Data types
# ============================================================================


@dataclass
class WorkflowMetaPhase:
    title: str
    detail: str | None = None
    model: str | None = None


@dataclass
class WorkflowMeta:
    name: str
    description: str
    when_to_use: str | None = None
    phases: list[WorkflowMetaPhase] | None = None


@dataclass
class AgentOptions:
    label: str | None = None
    phase: str | None = None
    schema: dict | None = None
    model: str | None = None
    isolation: str | None = None
    agent_type: str | None = None


@dataclass
class WorkflowRunResult:
    meta: WorkflowMeta
    result: Any
    logs: list[str]
    phases: list[str]
    agent_count: int
    duration_ms: float


@dataclass
class WorkflowRunOptions:
    args: Any = None
    agent: Any = None  # WorkflowAgent instance, injected by tool
    concurrency: int | None = None
    token_budget: int | None = None
    cwd: str | None = None
    signal: Any = None  # asyncio.Event for abort


# ============================================================================
# AST literal evaluator for meta
# ============================================================================


def _evaluate_ast_node(node: ast.AST) -> Any:
    """Evaluate a literal AST node. Raises ValueError for non-literal nodes."""
    match node:
        case ast.Constant(value=v) if isinstance(v, (str, int, float, bool)) or v is None:
            return v
        case ast.Constant(value=v):
            raise ValueError(f"unsupported constant type: {type(v).__name__}")
        case ast.List(elts=elts):
            return [_evaluate_ast_node(e) for e in elts]
        case ast.Dict(keys=keys, values=values):
            result: dict = {}
            for k, v in zip(keys, values):
                if k is None:
                    raise ValueError("dict unpacking (**) not allowed in meta")
                key = _evaluate_ast_node(k)
                if not isinstance(key, (str, int, float, bool)):
                    raise ValueError(f"dict key must be string or number, got {type(key).__name__}")
                result[key] = _evaluate_ast_node(v)
            return result
        case ast.UnaryOp(op=ast.USub(), operand=ast.Constant(value=(int() | float()) as v)):
            return -v
        case ast.Expr(value=inner):
            return _evaluate_ast_node(inner)
        case _:
            raise ValueError(f"non-literal node in meta: {type(node).__name__}")


# ============================================================================
# Deterministic check
# ============================================================================


class _DeterminismVisitor(ast.NodeVisitor):
    """Walk AST and reject dangerous constructs."""

    def visit_Import(self, node: ast.Import):
        raise ValueError("import statements are not allowed in workflow scripts")

    def visit_ImportFrom(self, node: ast.ImportFrom):
        raise ValueError("import statements are not allowed in workflow scripts")

    def visit_Call(self, node: ast.Call):
        # Reject open(), eval(), exec(), compile(), __import__(), globals(), locals()
        match node.func:
            case ast.Name(id=name) if name in ("open", "eval", "exec", "compile", "globals", "locals", "__import__"):
                raise ValueError(f"{name}() is not allowed in workflow scripts")
            case ast.Attribute(attr=attr) if attr in ("__import__", "__subclasses__", "__class__"):
                raise ValueError(f".{attr} is not allowed in workflow scripts")
        self.generic_visit(node)


# ============================================================================
# Script parser
# ============================================================================


def parse_workflow_script(script: str) -> tuple[WorkflowMeta, str]:
    """
    Parse a workflow script, extracting meta from the first statement.

    The first statement must be: meta = { name: '...', description: '...' }

    Returns (meta, body) where body is the script with the meta assignment removed.
    """
    try:
        tree = ast.parse(script, mode="exec")
    except SyntaxError as e:
        raise ValueError(f"workflow script has invalid syntax: {e}") from e

    if not tree.body:
        raise ValueError("workflow script is empty")

    first = tree.body[0]

    # First statement must be: meta = { ... }
    if not isinstance(first, ast.Assign):
        raise ValueError("`meta = { name, description }` must be the first statement in the script")
    if len(first.targets) != 1:
        raise ValueError("`meta = { name, description }` must be the first statement in the script")
    target = first.targets[0]
    if not isinstance(target, ast.Name) or target.id != "meta":
        raise ValueError("first assignment must be to `meta`")
    if first.value is None:
        raise ValueError("meta must have a literal value")

    try:
        meta_value = _evaluate_ast_node(first.value)
    except ValueError as e:
        raise ValueError(f"meta must be a plain literal object: {e}") from e

    if not isinstance(meta_value, dict):
        raise ValueError("meta must be a dict literal")

    meta = _validate_meta(meta_value)

    # Run determinism check on the body (everything after meta assignment)
    for node in tree.body[1:]:
        _DeterminismVisitor().visit(node)

    # Extract body text: everything after the meta = {...} statement
    # Use ast's end position info (Python 3.8+)
    meta_end_line = first.end_lineno
    script_lines = script.split("\n")
    body_lines = script_lines[meta_end_line:]  # end_lineno is 1-based, so this skips the meta line
    body = "\n".join(body_lines)

    return meta, body


def _validate_meta(value: dict) -> WorkflowMeta:
    name = value.get("name")
    description = value.get("description")

    if not isinstance(name, str) or not name.strip():
        raise ValueError("meta.name must be a non-empty string")
    if not isinstance(description, str) or not description.strip():
        raise ValueError("meta.description must be a non-empty string")

    when_to_use = value.get("whenToUse") or value.get("when_to_use")
    if when_to_use is not None and not isinstance(when_to_use, str):
        raise ValueError("meta.whenToUse must be a string")

    phases_raw = value.get("phases")
    phases: list[WorkflowMetaPhase] | None = None
    if phases_raw is not None:
        if not isinstance(phases_raw, list):
            raise ValueError("meta.phases must be a list")
        phases = []
        for p in phases_raw:
            if not isinstance(p, dict) or not isinstance(p.get("title"), str):
                raise ValueError("each meta phase must have a title string")
            phases.append(
                WorkflowMetaPhase(
                    title=p["title"],
                    detail=p.get("detail"),
                    model=p.get("model"),
                )
            )

    return WorkflowMeta(
        name=name.strip(),
        description=description.strip(),
        when_to_use=when_to_use if isinstance(when_to_use, str) else None,
        phases=phases,
    )


# ============================================================================
# Sandbox helpers
# ============================================================================


def _build_safe_builtins(log_fn: Callable[[str], None]) -> dict:
    """Build a restricted __builtins__ dict for the sandbox."""
    return {
        "True": True,
        "False": False,
        "None": None,
        "str": str,
        "int": int,
        "float": float,
        "bool": bool,
        "list": list,
        "dict": dict,
        "set": set,
        "tuple": tuple,
        "len": len,
        "range": range,
        "enumerate": enumerate,
        "isinstance": isinstance,
        "type": type,
        "print": log_fn,
        "abs": abs,
        "min": min,
        "max": max,
        "sum": sum,
        "sorted": sorted,
        "reversed": reversed,
        "zip": zip,
        "map": map,
        "filter": filter,
        "any": any,
        "all": all,
        "Exception": Exception,
        "ValueError": ValueError,
        "TypeError": TypeError,
        "KeyError": KeyError,
        "IndexError": IndexError,
    }


def _default_agent_label(phase: str | None, index: int) -> str:
    return f"{phase} agent {index}" if phase else f"agent {index}"


def _build_agent_instructions(phase: str | None, options: AgentOptions) -> str | None:
    lines = []
    if phase:
        lines.append(f"Workflow phase: {phase}")
    if options.agent_type:
        lines.append(f"Act as workflow subagent type: {options.agent_type}")
    if options.isolation:
        lines.append(f"Requested isolation: {options.isolation}")
    if options.model:
        lines.append(f"Requested model: {options.model}")
    return "\n".join(lines) if lines else None


def _estimate_tokens(value: Any) -> int:
    return max(1, len(json_module.dumps(value if value is not None else "")) // 4)


def _normalize_agent_options(value: Any) -> AgentOptions:
    if value is None:
        return AgentOptions()
    if not isinstance(value, dict):
        raise TypeError("agent options must be a dict")
    return AgentOptions(
        label=_optional_str(value.get("label"), "agent label"),
        phase=_optional_str(value.get("phase"), "agent phase"),
        schema=value.get("schema"),
        model=_optional_str(value.get("model"), "agent model"),
        isolation=_optional_str(value.get("isolation"), "agent isolation"),
        agent_type=_optional_str(value.get("agentType") or value.get("agent_type"), "agent type"),
    )


def _require_str(value: Any, name: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{name} must be a string")
    return value


def _optional_str(value: Any, name: str) -> str | None:
    if value is None:
        return None
    return _require_str(value, name)


def _assert_serializable(value: Any, name: str) -> None:
    try:
        json_module.dumps(value)
    except (TypeError, ValueError) as e:
        raise ValueError(
            f"{name} must be JSON-serializable; did you forget to await agent(), parallel(), or pipeline()? {e}"
        ) from e


# ============================================================================
# Runtime
# ============================================================================


async def run_workflow(script: str, options: WorkflowRunOptions | None = None) -> WorkflowRunResult:
    """
    Execute a workflow script in a sandbox.

    The script's meta assignment is parsed first, then the body is executed
    inside a restricted exec() context with agent(), parallel(), pipeline(),
    phase(), log(), args, cwd, and budget globals.
    """
    options = options or WorkflowRunOptions()
    started = time.monotonic()

    meta, body = parse_workflow_script(script)

    state = {
        "current_phase": None,
        "logs": [],
        "phases": [],
        "agent_count": 0,
        "spent": 0,
    }

    # Determine concurrency
    cpu_count = os.cpu_count() or 4
    default_concurrency = max(1, min(cpu_count - 2, 16))
    concurrency = max(1, min(options.concurrency or default_concurrency, 16))
    sem = asyncio.Semaphore(concurrency)
    pending_agent_runs: set[asyncio.Task] = set()

    signal = options.signal

    def _check_aborted():
        if signal and signal.is_set():
            raise asyncio.CancelledError("workflow aborted")

    # ── log ──
    def _log(message: str):
        text = str(message)
        state["logs"].append(text)

    # ── phase ──
    def _phase(title: str):
        _require_str(title, "phase title")
        state["current_phase"] = title
        if title not in state["phases"]:
            state["phases"].append(title)

    # ── budget ──
    class _Budget:
        total = options.token_budget

        @staticmethod
        def spent():
            return state["spent"]

        @staticmethod
        def remaining():
            if _Budget.total is None:
                return float("inf")
            return max(0, _Budget.total - state["spent"])

    # ── agent ──
    async def _agent(prompt: Any, agent_opts: Any = None):
        _check_aborted()
        if _Budget.total is not None and _Budget.remaining() <= 0:
            raise RuntimeError("workflow token budget exhausted")

        task_prompt = _require_str(prompt, "agent prompt")
        norm_opts = _normalize_agent_options(agent_opts)
        assigned_phase = norm_opts.phase or state["current_phase"]
        requested_label = norm_opts.label.strip() if norm_opts.label else None

        async def _agent_runner():
            nonlocal requested_label
            state["agent_count"] += 1
            label = requested_label or _default_agent_label(assigned_phase, state["agent_count"])

            _check_aborted()

            # If options.agent is injected, use it (real subagent)
            # Otherwise use None (test mock)
            runner = options.agent
            if runner is None:
                # No agent runner provided — return placeholder for testing
                return f"[result for: {task_prompt}]"

            try:
                instructions = _build_agent_instructions(assigned_phase, norm_opts)
                result = await runner.run(
                    task_prompt,
                    label=label,
                    schema=norm_opts.schema,
                    instructions=instructions,
                    signal=signal,
                )
                _check_aborted()
                state["spent"] += _estimate_tokens(result)
                return result
            except Exception as e:
                if signal and signal.is_set():
                    raise
                _log(f"agent {label} failed: {e}")
                return None

        async with sem:
            return await _agent_runner()

    # ── parallel ──
    async def _parallel(thunks: list):
        _check_aborted()
        if not isinstance(thunks, list):
            raise TypeError("parallel() expects a list of functions")

        async def _safe_thunk(thunk, index):
            try:
                return await thunk()
            except Exception as e:
                if signal and signal.is_set():
                    raise
                _log(f"parallel[{index}] failed: {e}")
                return None

        return await asyncio.gather(*[_safe_thunk(t, i) for i, t in enumerate(thunks)])

    # ── pipeline ──
    async def _pipeline(items: list, *stages):
        _check_aborted()
        if not isinstance(items, list):
            raise TypeError("pipeline() expects a list as the first argument")

        async def _run_item(item, index):
            value = item
            for stage in stages:
                _check_aborted()
                try:
                    result = stage(value, item, index)
                    if asyncio.iscoroutine(result):
                        value = await result
                    else:
                        value = result
                except Exception as e:
                    if signal and signal.is_set():
                        raise
                    _log(f"pipeline[{index}] failed: {e}")
                    return None
            return value

        return await asyncio.gather(*[_run_item(item, i) for i, item in enumerate(items)])

    # ── Build sandbox ──
    sandbox_globals: dict[str, Any] = {
        "agent": _agent,
        "parallel": _parallel,
        "pipeline": _pipeline,
        "log": _log,
        "phase": _phase,
        "args": options.args,
        "cwd": options.cwd or os.getcwd(),
        "budget": _Budget(),
        "JSON": json_module,
        "Math": math,
        "Array": list,
        "Object": dict,
        "Map": dict,
        "Set": set,
        "__builtins__": _build_safe_builtins(_log),
    }

    # ── Execute ──
    wrapper = f"async def __workflow__():\n" + "\n".join(f"  {line}" for line in body.split("\n"))
    local_vars: dict[str, Any] = {}
    exec(wrapper, sandbox_globals, local_vars)
    result = await local_vars["__workflow__"]()

    # Wait for any pending background agent calls
    if pending_agent_runs:
        await asyncio.gather(*pending_agent_runs, return_exceptions=True)

    _assert_serializable(result, "workflow result")

    return WorkflowRunResult(
        meta=meta,
        result=result,
        logs=state["logs"],
        phases=state["phases"],
        agent_count=state["agent_count"],
        duration_ms=(time.monotonic() - started) * 1000,
    )
